import React from 'react'

const likedmovies = () => {
  return (
    <div className='bg-black'>likedmovies</div>
  )
}

export default likedmovies