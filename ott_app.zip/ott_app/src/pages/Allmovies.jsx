import React from 'react'
import Moviecards from '../components/moviecards'
const Allmovies = () => {
  return (
    <div >
        <Moviecards dynamiccss1='p-5' dynamiccss2='grid grid-cols-4 gap-4'/>
    </div>
  )
}

export default Allmovies